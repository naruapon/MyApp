//
//  Storyboard_Example_Part6AppDelegate.h
//  Storyboard-Example-Part6
//
//  Created by Vit on 10/17/12.
//  Copyright (c) 2012 BlueMango. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Storyboard_Example_Part6AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
