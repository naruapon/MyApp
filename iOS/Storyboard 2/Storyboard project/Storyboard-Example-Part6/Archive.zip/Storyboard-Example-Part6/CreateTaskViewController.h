//
//  CreateTaskViewController.h
//  Storyboard-Example-Part6
//
//  Created by Vit on 10/22/12.
//  Copyright (c) 2012 BlueMango. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CreateTaskViewController : UIViewController{
    IBOutlet UITextField* taskNameText;
    IBOutlet UITextField* taskDescriptionText;
}
@end
