//
//  Storyboard_Example_Part6ViewController.m
//  Storyboard-Example-Part6
//
//  Created by Vit on 10/17/12.
//  Copyright (c) 2012 BlueMango. All rights reserved.
//

#import "Storyboard_Example_Part6ViewController.h"
#import "ListOfTasksViewController.h"
@interface Storyboard_Example_Part6ViewController ()

@end

@implementation Storyboard_Example_Part6ViewController

#pragma mark View defailt methods
- (void)viewDidLoad
{
    [super viewDidLoad];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Storyboard delegate stuff
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
	if ([segue.identifier isEqualToString:@"GoToTaskListSegue"])
	{
        // Get reference to the destination view controller
        ListOfTasksViewController *taskListView = (ListOfTasksViewController*)[segue destinationViewController];
//        if (resultImage != nil) {
            // send image here
            [taskListView setSession];
//        }
	}
}
@end
