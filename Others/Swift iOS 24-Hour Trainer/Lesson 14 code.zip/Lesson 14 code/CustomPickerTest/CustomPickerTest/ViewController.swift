//
//  ViewController.swift
//  CustomPickerTest
//
//  Created by Abhishek Mishra on 26/04/2015.
//  Copyright (c) 2015 asm technology ltd. All rights reserved.
//

import UIKit

class ViewController: UIViewController,
                      UIPickerViewDataSource,
                      UIPickerViewDelegate {

    @IBOutlet weak var pickerView: UIPickerView!
    @IBOutlet weak var resultsLabel: UILabel!
    
    let dataForComponent1:[String] = ["Apple", "Banana", "Lemon",
                                      "Orange", "Peach", "Pear",
                                      "Pineapple"]
    
    let dataForComponent2:[String] = ["Banana", "Orange", "Pear",
                                      "Apple", "Pineapple", "Lemon",
                                      "Peach"]
    
    let dataForComponent3:[String] = ["Pear", "Peach", "Lemon",
                                      "Pineapple", "Apple", "Banana",
                                      "Orange"]
    
    
    let nameToImageMapping:[String:String] = ["Apple":"appleImages",
                                            "Banana":"bananaImages",
                                            "Lemon":"lemonImages",
                                            "Orange":"orangeImages",
                                            "Peach":"peachImages",
                                            "Pear":"pearImages",
                                            "Pineapple":"pineappleImages"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        resultsLabel.text = "Match the fruits in each row!"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int
    {
        return 3
    }

    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        if component == 0
        {
            return dataForComponent1.count
        }
        else if component == 1
        {
            return dataForComponent2.count
        }
        else
        {
            return dataForComponent3.count
        }
    }
    
    func pickerView(pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat
    {
        return 50
    }
    
    
    func pickerView(pickerView: UIPickerView,
        viewForRow row: Int,
        forComponent component: Int,
        reusingView view: UIView?) -> UIView
    {
        // get the fruit name
        var keyString:String? = nil
        
        if component == 0
        {
            keyString = dataForComponent1[row]
        }
        else if component == 1
        {
            keyString = dataForComponent2[row]
        }
        else if component == 2
        {
            keyString = dataForComponent3[row]
        }
        
        let imageFileName:String? = nameToImageMapping[keyString!]
        
        if view == nil
        {
            return UIImageView(image:UIImage(named: imageFileName!));
        }
        
        let imageView:UIImageView = view as! UIImageView
        
        imageView.image = UIImage(named: imageFileName!)
        
        return imageView;
    }
    
    func pickerView(pickerView: UIPickerView,
        didSelectRow row: Int,
        inComponent component: Int)
    {
        // get selected fruit in each component
        let selectedRowInComponent1 = pickerView.selectedRowInComponent(0)
        let fruitInComponent1:String! = dataForComponent1[selectedRowInComponent1]
        
        let selectedRowInComponent2 = pickerView.selectedRowInComponent(1)
        let fruitInComponent2:String! = dataForComponent2[selectedRowInComponent2]
        
        let selectedRowInComponent3 = pickerView.selectedRowInComponent(2)
        let fruitInComponent3 = dataForComponent3[selectedRowInComponent3]
        
        // if the same fruit is selected in
        // each row, then show a message
        if fruitInComponent1 == fruitInComponent2 &&
            fruitInComponent2 == fruitInComponent3
        {
            resultsLabel.text = "Jackpot!";
        }
            else
        {
            resultsLabel.text = "Match the fruits in each row!";
        }
    }

}

