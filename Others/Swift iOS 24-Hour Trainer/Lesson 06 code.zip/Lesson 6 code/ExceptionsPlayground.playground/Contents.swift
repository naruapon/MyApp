//: Playground - noun: a place where people can play

import Foundation

enum ArithmeticError: ErrorType {
    case DivisionByZero
}

func divideNumebrs(numerator n:Double, denominator d:Double) throws -> Double
{
    if d == 0
    {
        throw ArithmeticError.DivisionByZero
    }
    
    return n / d
}

func performDivision(number1:Double, _ number2:Double)
{
    do{
        let result = try divideNumebrs(numerator: number1, denominator: number2)
        
        print("\(number1) divided by \(number2) equals \(result)")
        
    }
    catch
    {
        print ("number2 is zero!")
    }
}

performDivision(10, 2)
