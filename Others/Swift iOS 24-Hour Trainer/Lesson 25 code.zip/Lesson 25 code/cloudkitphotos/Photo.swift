//
//  Photo.swift
//  cloudkitphotos
//
//  Created by Abhishek Mishra on 03/09/2015.
//  Copyright © 2015 asm technology ltd. All rights reserved.
//

import Foundation
import CoreData
import CloudKit
import UIKit

class Photo: NSManagedObject {

    static func addFromCKRecord(record:CKRecord) {
        
        // read fields from CKRecord
        let recordIdentifier:String = record.recordID.recordName
        
        guard let
            dateTaken:NSDate = record["dateTaken"] as? NSDate,
            fileName:String = record["filename"] as? String,
            photoCaption:String = record["photoCaption"] as? String,
            photoDescription:String = record["photoDescription"] as? String,
            asset:CKAsset = record["photoAsset"] as? CKAsset else {
                return
        }
        
        // save asset to documents directory
        guard let image = UIImage(contentsOfFile:asset.fileURL.path!) else {
            print ("unable to download image")
            return
        }
        
        saveImageToDocumentsDirectory(image, fileName)
        
        // insert new record.
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let newItem = NSEntityDescription.insertNewObjectForEntityForName("Photo", inManagedObjectContext: appDelegate.managedObjectContext) as! Photo
        
        newItem.ckRecordID = recordIdentifier
        newItem.fileName = fileName
        newItem.dateTaken = dateTaken
        newItem.photoCaption = photoCaption
        newItem.photoDescription = photoDescription
        
        // save managed object context.
        do {
            try appDelegate.managedObjectContext.save()
        }
        catch {
            print("error saving managed object context")
        }
    }

    
    static func saveImageToDocumentsDirectory(image: UIImage, _ fileName:String) -> NSURL
    {
        let documentsURL = NSFileManager.defaultManager().URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask)[0]
        let fileURL = documentsURL.URLByAppendingPathComponent(fileName)
        UIImageJPEGRepresentation(image, 0.5)?.writeToURL(fileURL, atomically: true)
        return fileURL
    }
}
