//
//  DetailViewController.swift
//  cloudkitphotos
//
//  Created by Abhishek Mishra on 02/09/2015.
//  Copyright © 2015 asm technology ltd. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var detailLabel: UILabel!
    @IBOutlet weak var captionLabel: UILabel!
    
    var modelObject:Photo?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        guard let
            modelObject = modelObject,
            photoDescription = modelObject.photoDescription,
            photoCaption = modelObject.photoCaption,
            imageFileName = modelObject.fileName else {
                return
        }
        
        detailLabel.text = photoDescription
        captionLabel.text = photoCaption
        loadImageFromFileInDocumentsDirectory(imageFileName)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    func loadImageFromFileInDocumentsDirectory(imageFileName:String) {
        
        let documentsURL = NSFileManager.defaultManager().URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask)[0]
        let fileURL = documentsURL.URLByAppendingPathComponent(imageFileName)
        let image:UIImage? = UIImage(contentsOfFile: fileURL.path!)
        
        if (image != nil) {
            imageView.image = image
            imageView.contentMode = UIViewContentMode.ScaleAspectFit
        }
        
    }
    
}

