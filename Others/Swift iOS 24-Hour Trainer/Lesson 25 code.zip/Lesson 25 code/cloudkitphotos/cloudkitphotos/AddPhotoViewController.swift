//
//  AddPhotoViewController.swift
//  cloudkitphotos
//
//  Created by Abhishek Mishra on 04/09/2015.
//  Copyright © 2015 asm technology ltd. All rights reserved.
//

import UIKit
import CloudKit

class AddPhotoViewController: UIViewController , UIImagePickerControllerDelegate, UINavigationControllerDelegate  {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var captionField: UITextField!
    @IBOutlet weak var descriptionField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        captionField.placeholder = "Photo caption"
        descriptionField.placeholder = "Photo description"
        
        let tapRecognizer = UITapGestureRecognizer(target:self , action: Selector("handleBackgroundTap:"))
        tapRecognizer.cancelsTouchesInView = false
        self.view.addGestureRecognizer(tapRecognizer)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func onSelectPicture(sender: AnyObject) {
            
        guard let cameraButton = sender as? UIButton else {
            return
        }
            
        let imagePicker:UIImagePickerController = UIImagePickerController()
        imagePicker.sourceType = UIImagePickerControllerSourceType.PhotoLibrary
        imagePicker.delegate = self
            
        if UIDevice().userInterfaceIdiom == UIUserInterfaceIdiom.Pad
        {
            imagePicker.modalPresentationStyle = UIModalPresentationStyle.Popover
            self.presentViewController(imagePicker, animated: true, completion: nil)
            
            let presentationController:UIPopoverPresentationController = imagePicker.popoverPresentationController!
            presentationController.permittedArrowDirections = UIPopoverArrowDirection.Left
            presentationController.sourceView = self.view
            presentationController.sourceRect = cameraButton.frame
        }
        else
        {
            self.presentViewController(imagePicker, animated: true, completion: nil)
        }
    }
    
    @IBAction func onSaveRecord(sender: AnyObject) {
        
        // ensure data has been filled.
        guard let photoCaption = captionField.text,
            photoDescription:String = descriptionField.text,
            let image = imageView.image else {
        
                // user has not filled in all fields
                let alert = UIAlertController(title: "Incomplete information!",
                    message: "You must select an image, provide a caption and a description.",
                    preferredStyle: UIAlertControllerStyle.Alert)
                
                alert.addAction(UIAlertAction(title: "Ok",
                    style: UIAlertActionStyle.Default,
                    handler: nil))
                
                self.presentViewController(alert,
                    animated: true,
                    completion: nil)
                
                return
        }
        
        if photoCaption.characters.count == 0 ||
            photoDescription.characters.count == 0 {
                // user has not filled in all fields
                let alert = UIAlertController(title: "Incomplete information!",
                    message: "You must select an image, provide a caption and a description.",
                    preferredStyle: UIAlertControllerStyle.Alert)
                
                alert.addAction(UIAlertAction(title: "Ok",
                    style: UIAlertActionStyle.Default,
                    handler: nil))
                
                self.presentViewController(alert,
                    animated: true,
                    completion: nil)
                
                return
        }
        
        // generate a unique record identifier
        let uuid:String = NSUUID().UUIDString
        let photoRecordID:CKRecordID = CKRecordID(recordName: uuid)
        
        // save the image to a file in the documents directory
        let fileName:String = "\(uuid).jpg"
        let fileURL:NSURL = Photo.saveImageToDocumentsDirectory(image, fileName)
        
        // make a CKAsset from the file.
        let photoAsset:CKAsset = CKAsset(fileURL: fileURL)
        
        // create a photoRecord
        let photoRecord:CKRecord = CKRecord(recordType: "Photo", recordID: photoRecordID)
        photoRecord["photoCaption" ] = photoCaption
        photoRecord["photoDescription"] = photoDescription
        photoRecord["dateTaken"] = NSDate()
        photoRecord["filename"] = fileName
        photoRecord["photoAsset"] = photoAsset
        
        // save the record to the public database with CloudKit
        let publicDatabase:CKDatabase = CKContainer.defaultContainer().publicCloudDatabase
        
        publicDatabase.saveRecord(photoRecord) { (newRecord, error) -> Void in
            
            if error != nil {
                let alert = UIAlertController(title: "Error!",
                    message: "Error saving to Cloudkit",
                    preferredStyle: UIAlertControllerStyle.Alert)
                
                alert.addAction(UIAlertAction(title: "Ok",
                    style: UIAlertActionStyle.Default,
                    handler: nil))
                
                self.presentViewController(alert,
                    animated: true,
                    completion: nil)
                
                return
            }
            
            self.dismissViewControllerAnimated(true, completion: nil)
        }
        
        
    }
 
    @IBAction func onCancel(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    @IBAction func onDismissKeyboard(sender: AnyObject) {
        captionField.resignFirstResponder()
        descriptionField.resignFirstResponder()
    }
    
    //MARK: Gesture Recognizer
    
    func handleBackgroundTap(sender: UITapGestureRecognizer) {
        captionField.resignFirstResponder()
        descriptionField.resignFirstResponder()
    }
    
    //MARK: UIImagePickerControllerDelegate
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        let image:UIImage = info[UIImagePickerControllerOriginalImage] as! UIImage
        imageView.image = image
            
        picker.dismissViewControllerAnimated(true, completion: nil)
    }

    func imagePickerControllerDidCancel(picker: UIImagePickerController)
    {
        picker.dismissViewControllerAnimated(true, completion: nil)
    }

    
    
}
