//
//  ViewController.swift
//  cloudkitphotos
//
//  Created by Abhishek Mishra on 01/09/2015.
//  Copyright © 2015 asm technology ltd. All rights reserved.
//

import UIKit
import CloudKit
import CoreData

protocol CloudLoaderDelegate : NSObjectProtocol {
    
    func willProcessRecords(recordType:String, _ records:[CKRecord]?)
    
    func processCKRecord(recordType:String, _ record:CKRecord)
    
    func didProcessRecords(recordType:String, _ records:[CKRecord]?)
    
    func didReceiveError(recordType:String, _ error:NSError?)
}

class ViewController: UITableViewController, CloudLoaderDelegate {

    var photos:[Photo]?
    var publicDatabase:CKDatabase?
    var matchAllPredicate:NSPredicate?
    
    // Block variable to download all records of the specified type 
    // from CloudKit and pass the records to a delegate object for
    // further processing.
    //
    // Inputs: The record type as String, 
    //         A CKDatabase instance, 
    //         A predicate used for query matching, and
    //         A delegate object that is called
    //              a) when an error is received from CloudKit
    //              b) just before processing downloaded CKRecords
    //              c) to process each CKRecord
    //              d) just after the last CKRecord have been processed.
    let recordDownloadBlock: (String, CKDatabase, NSPredicate, CloudLoaderDelegate) -> Void = { (recordType, database, predicate, delegate) -> Void in
        
        let query = CKQuery(recordType: recordType, predicate: predicate)
        
        database.performQuery(query, inZoneWithID: nil) { results, error in
            
            if error != nil{
                delegate.didReceiveError(recordType, error)
                return
            }
            
            guard let results = results else {
                delegate.didProcessRecords(recordType, nil)
                return
            }
            
            // delete photographer records from Core Data
            delegate.willProcessRecords(recordType, results)
            
            for record in results {
                delegate.processCKRecord(recordType, record)
            }
            
            delegate.didProcessRecords(recordType, results)
        }
    }
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        self.publicDatabase = CKContainer.defaultContainer().publicCloudDatabase
        self.matchAllPredicate = NSPredicate(value: true)
        
    }

    override func viewDidAppear(animated: Bool) {
        
        super.viewDidAppear(animated)
        
        fetchListOfPhotos()
        tableView.reloadData()
        
        downloadPhotosFromCloud(recordDownloadBlock)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func downloadPhotosFromCloud(completionBlock : (String, CKDatabase, NSPredicate, CloudLoaderDelegate) -> Void) {
        
        CKContainer.defaultContainer().accountStatusWithCompletionHandler { (accountStatus, error) -> Void in
            
            if accountStatus == CKAccountStatus.NoAccount {
                // user has not signed in to iCloud, show an alert.
                let alert = UIAlertController(title: "Sign in to iCloid",
                    message: "You need to sign in to iCloud to create records.",
                    preferredStyle: UIAlertControllerStyle.Alert)
                
                alert.addAction(UIAlertAction(title: "Ok",
                    style: UIAlertActionStyle.Default,
                    handler: nil))
                
                self.presentViewController(alert,
                    animated: true,
                    completion: nil)
            }
            else {
                // user has signed in to iCloud, download Photo from server
                completionBlock("Photo", self.publicDatabase!, self.matchAllPredicate!, self);
            }
        }

    }
    
    // MARK: CloudLoaderDelegate
    func willProcessRecords(recordType:String, _ records:[CKRecord]?)
    {
        // delete all Photos from core data before processing new ones in CloudKit
        
        let fetchRequest = NSFetchRequest(entityName: "Photo")
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        var results:[Photo]? = nil
        
        do {
            results = try appDelegate.managedObjectContext.executeFetchRequest(fetchRequest) as? [Photo]
            guard let results = results else {
                return
            }
            
            for photo in results {
                appDelegate.managedObjectContext.deleteObject(photo)
            }
            
            try appDelegate.managedObjectContext.save()
        }
        catch {
            print ("error retrieving list of photos from local database.")
        }
    }
    
    
    func processCKRecord(recordType:String, _ record:CKRecord)
    {
        if recordType.compare("Photo") == NSComparisonResult.OrderedSame {
            Photo.addFromCKRecord(record)
        }
    }
    

    func didProcessRecords(recordType:String, _ records:[CKRecord]?)
    {
        if recordType.compare("Photo") == NSComparisonResult.OrderedSame {
            fetchListOfPhotos()
            tableView.reloadData()
        }
    }
    
    func didReceiveError(recordType:String, _ error:NSError?)
    {
        print ("received error \(error) for record type \(recordType)")
    }
    
    
    // MARK: Core Data support
    
    func fetchListOfPhotos()
    {
        let fetchRequest = NSFetchRequest(entityName: "Photo")
        
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        
        do {
            self.photos = try appDelegate.managedObjectContext.executeFetchRequest(fetchRequest) as? [Photo]
        }
        catch {
            print ("error retrieving list of photos from local database.")
        }
        
    }
    
    // MARK: Tableview datasource methods
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if photos != nil {
            return photos!.count
        }
        
        return 0
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        let cell:UITableViewCell = tableView.dequeueReusableCellWithIdentifier("prototypeCell1", forIndexPath: indexPath)
        
        let somePhoto:Photo! = photos![indexPath.row]
        
        cell.textLabel?.text = somePhoto.photoCaption
        
        return cell
    }
    
    // MARK: Segues
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        guard let identifier = segue.identifier else {
            return
        }
        
        if identifier.compare("showPhotoDetail") == NSComparisonResult.OrderedSame {
        
            guard let
                detailViewController = segue.destinationViewController as? DetailViewController else {
                return
            }
            
            guard let indexPath = tableView.indexPathForSelectedRow,
                arrayOfPhotos = self.photos else {
                    return
            }
            

            let modelObject:Photo = arrayOfPhotos[indexPath.row]
            detailViewController.modelObject = modelObject
        }
    }


}

