//
//  Photo+CoreDataProperties.swift
//  cloudkitphotos
//
//  Created by Abhishek Mishra on 04/09/2015.
//  Copyright © 2015 asm technology ltd. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension Photo {

    @NSManaged var ckRecordID: String?
    @NSManaged var dateTaken: NSDate?
    @NSManaged var fileName: String?
    @NSManaged var photoCaption: String?
    @NSManaged var photoDescription: String?

}
