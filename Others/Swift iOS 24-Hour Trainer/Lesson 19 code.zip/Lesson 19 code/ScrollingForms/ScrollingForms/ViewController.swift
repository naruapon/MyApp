//
//  ViewController.swift
//  ScrollingForms
//
//  Created by Abhishek Mishra on 25/05/2015.
//  Copyright (c) 2015 asm technology ltd. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var scrollView: UIScrollView!
    
    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var addressField1: UITextField!
    @IBOutlet weak var addressField2: UITextField!
    @IBOutlet weak var postcodeField: UITextField!
    
    var keyboardHeight:Float = 0
    var currentTextField:UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        usernameField.delegate = self
        passwordField.delegate = self
        addressField1.delegate = self
        addressField2.delegate = self
        postcodeField.delegate = self
        
    }
    
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("keyboardDidShow:"), name: UIKeyboardDidShowNotification , object: self.view.window)
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("keyboardDidHide:"), name: UIKeyboardDidHideNotification , object: nil)
    }

    override func viewDidDisappear(animated: Bool) {
        
        super.viewDidDisappear(animated)
        
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func keyboardDidShow(sender: NSNotification!)
    {
        // get height of keyboard
        let info: NSDictionary = sender.userInfo!
        let value: NSValue = info.valueForKey(UIKeyboardFrameEndUserInfoKey) as! NSValue
        let keyboardFrame: CGRect = value.CGRectValue()
        
        // convert from Core Graphics CGFloat to Swift Float
        let cgFloatKeyboardHeight:CGFloat = keyboardFrame.size.height
        
        keyboardHeight = Float(cgFloatKeyboardHeight)

        // ensure current text field is visible, if not adjust the contentOffset
        // of the scrollView appropriately.
        let textFieldTop:Float = Float(currentTextField.frame.origin.y)
        let textFieldBottom:Float = textFieldTop + Float(currentTextField.frame.size.height)
        
        if (textFieldBottom > keyboardHeight)
        {
            scrollView.setContentOffset(CGPointMake(0, CGFloat(textFieldBottom - keyboardHeight)), animated: true)
        }
    }
    
    func keyboardDidHide(sender: NSNotification!)
    {
        scrollView.setContentOffset(CGPointMake(0, 0), animated: false)
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true;
    }
    
    func textFieldDidBeginEditing(textField: UITextField)
    {
        currentTextField = textField
     
        let textFieldTop:Float = Float(currentTextField.frame.origin.y)
        let textFieldBottom:Float = textFieldTop + Float(currentTextField.frame.size.height)
        
        if textFieldBottom > keyboardHeight && keyboardHeight != 0.0
        {
            scrollView.setContentOffset(CGPointMake(0, CGFloat(textFieldBottom - keyboardHeight)), animated: true)
        }
    }
}

