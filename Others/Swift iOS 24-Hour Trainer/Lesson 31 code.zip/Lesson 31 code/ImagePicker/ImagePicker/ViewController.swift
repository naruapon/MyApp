//
//  ViewController.swift
//  ImagePicker
//
//  Created by Abhishek Mishra on 02/07/2015.
//  Copyright © 2015 Abhishek Mishra. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var cameraButton: UIButton!
    @IBOutlet weak var imageView: UIImageView!
    
    @IBAction func onCamera(sender: AnyObject) {
        let imagePicker:UIImagePickerController = UIImagePickerController()
        imagePicker.sourceType = UIImagePickerControllerSourceType.Camera
        imagePicker.delegate = self
        
        if UIDevice().userInterfaceIdiom == UIUserInterfaceIdiom.Pad
        {
            imagePicker.modalPresentationStyle = UIModalPresentationStyle.Popover
            self.presentViewController(imagePicker, animated: true, completion: nil)
            
            let presentationController:UIPopoverPresentationController = imagePicker.popoverPresentationController!
            presentationController.permittedArrowDirections = UIPopoverArrowDirection.Left
            presentationController.sourceView = self.view
            presentationController.sourceRect = cameraButton.frame
        }
        else
        {
            self.presentViewController(imagePicker, animated: true, completion: nil)
        }
    }
    
    @IBAction func onPhotoLibrary(sender: AnyObject) {
        let imagePicker:UIImagePickerController = UIImagePickerController()
        imagePicker.sourceType = UIImagePickerControllerSourceType.PhotoLibrary
        imagePicker.delegate = self
        
        if UIDevice().userInterfaceIdiom == UIUserInterfaceIdiom.Pad
        {
            imagePicker.modalPresentationStyle = UIModalPresentationStyle.Popover
            self.presentViewController(imagePicker, animated: true, completion: nil)
            
            let presentationController:UIPopoverPresentationController = imagePicker.popoverPresentationController!
            presentationController.permittedArrowDirections = UIPopoverArrowDirection.Left
            presentationController.sourceView = self.view
            presentationController.sourceRect = cameraButton.frame
        }
        else
        {
            self.presentViewController(imagePicker, animated: true, completion: nil)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let hasCamera = UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.Camera)
        if hasCamera == false
        {
            cameraButton.hidden = true;
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject])
    {
        let image:UIImage = info[UIImagePickerControllerOriginalImage] as! UIImage
        imageView.image = image
        
        picker.dismissViewControllerAnimated(true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(picker: UIImagePickerController)
    {
        picker.dismissViewControllerAnimated(true, completion: nil)
    }
}

