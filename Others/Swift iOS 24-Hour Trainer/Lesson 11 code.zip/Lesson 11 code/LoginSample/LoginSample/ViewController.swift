//
//  ViewController.swift
//  LoginSample
//
//  Created by Abhishek Mishra on 31/03/2015.
//  Copyright (c) 2015 asm technology ltd. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    
    func handleBackgroundTap(sender: UITapGestureRecognizer) {
        usernameField.resignFirstResponder();
        passwordField.resignFirstResponder()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tapRecognizer = UITapGestureRecognizer(target:self ,
                       action: Selector("handleBackgroundTap:"))
        
        tapRecognizer.cancelsTouchesInView = false
        self.view.addGestureRecognizer(tapRecognizer)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func onDismissKeyboard(sender: AnyObject) {
        usernameField.resignFirstResponder()
        passwordField.resignFirstResponder()
    }
    
    @IBAction func onLogin(sender: AnyObject) {
        
        usernameField.resignFirstResponder()
        passwordField.resignFirstResponder()
        
        let userName:String = usernameField.text!
        let length:Int = userName.characters.count
        
        if length == 0 {
            return
        }
        
        let alert = UIAlertController(title: "",
            message: "Login succesfull",
            preferredStyle: UIAlertControllerStyle.Alert)
        
        alert.addAction(UIAlertAction(title: "Ok",
            style: UIAlertActionStyle.Default,
            handler: nil))
        
        self.presentViewController(alert,
            animated: true,
            completion: nil)
    }

}

