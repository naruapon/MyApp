//
//  ViewController.swift
//  CoreDataTest
//
//  Created by Abhishek Mishra on 08/06/2015.
//  Copyright (c) 2015 asm technology ltd. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var phoneNumberField: UITextField!
    @IBOutlet weak var postCodeField: UITextField!
    @IBOutlet weak var tableOfContacts: UITableView!
    
    var listOfContacts:Array<ContactData>? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fetchExistingContacts()
        tableOfContacts.dataSource = self
        tableOfContacts.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func onAdd(sender: AnyObject) {
        
        nameField.resignFirstResponder()
        phoneNumberField.resignFirstResponder()
        postCodeField.resignFirstResponder()
        
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        
        let newCustomerName:String! = nameField.text
        let newCustomerPhoneNumber:String! = phoneNumberField.text
        let newCustomerPostcode:String! = postCodeField.text
        
        if newCustomerName.isEmpty && newCustomerPhoneNumber.isEmpty && newCustomerPostcode.isEmpty
        {
            return
        }
        
        let newItem = NSEntityDescription.insertNewObjectForEntityForName("ContactData",
            inManagedObjectContext: appDelegate.managedObjectContext) as! ContactData
        
        newItem.customerName = newCustomerName
        newItem.phoneNumber = newCustomerPhoneNumber
        newItem.postCode = newCustomerPostcode
        
        do {
            try appDelegate.managedObjectContext.save()
        } catch {
            // handle error.
        }
        
        fetchExistingContacts()
        tableOfContacts.reloadData()
        
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return listOfContacts!.count;
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCellWithIdentifier(
                   "ContactDataTableViewCellIdentifier",
                   forIndexPath: indexPath)
    
        let someContactData:ContactData! = listOfContacts![indexPath.row]
        
        cell.textLabel?.text = someContactData.customerName
        
        return cell
    }

    
    func fetchExistingContacts()
    {
        let fetchRequest = NSFetchRequest(entityName: "ContactData")
        
        let appDelegate = UIApplication.sharedApplication().delegate
                          as! AppDelegate
        
        do {
            self.listOfContacts = try
                appDelegate.managedObjectContext.executeFetchRequest(fetchRequest)
                as? [ContactData]
        } catch {
            // handle errors here.
        }
    }

}

