//
//  ViewController.swift
//  popoverTest
//
//  Created by Abhishek Mishra on 07/06/2015.
//  Copyright (c) 2015 asm technology ltd. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    
    var image:UIImage!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        image = UIImage(named: "Sunflower")
        
        imageView.image = image
        imageView.contentMode = UIViewContentMode.ScaleAspectFill
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == "imageInformationSegue" {
            let viewController:ImageInformationViewController = segue.destinationViewController as! ImageInformationViewController
            viewController.imageBeingDisplayed = self.image
        }

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

