//
//  ImageInformationViewController.swift
//  popoverTest
//
//  Created by Abhishek Mishra on 07/06/2015.
//  Copyright (c) 2015 asm technology ltd. All rights reserved.
//

import UIKit

class ImageInformationViewController: UIViewController {

    @IBOutlet weak var imageHeight: UITextField!
    @IBOutlet weak var imageWidth: UITextField!
    @IBOutlet weak var imageColorSpace: UITextField!
    
    var imageBeingDisplayed:UIImage!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let imageSize = imageBeingDisplayed.size
        let height = imageSize.height
        let width = imageSize.width
        
        imageHeight.text = "\(height)"
        imageWidth.text = "\(width)"
        imageColorSpace.text = "RGB"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

}
