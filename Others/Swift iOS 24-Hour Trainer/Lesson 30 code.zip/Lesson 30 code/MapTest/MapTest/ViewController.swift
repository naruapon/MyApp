//
//  ViewController.swift
//  MapTest
//
//  Created by Abhishek Mishra on 29/06/2015.
//  Copyright © 2015 Abhishek Mishra. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController, MKMapViewDelegate {

    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var mapModeSegmentControl: UISegmentedControl!
    
    @IBAction func onSegmentChanged(sender: AnyObject) {
        
        if mapModeSegmentControl.selectedSegmentIndex == 0
        {
            mapView.mapType = MKMapType.Standard;
        }
        else if mapModeSegmentControl.selectedSegmentIndex == 1
        {
            mapView.mapType = MKMapType.Satellite;
        }
            else if mapModeSegmentControl.selectedSegmentIndex == 2
        {
            mapView.mapType = MKMapType.Hybrid;
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
  
        // setup the map's location and zoom factor
        var mapRegion:MKCoordinateRegion = MKCoordinateRegion();
        mapRegion.center.latitude = 51.5001524;
        mapRegion.center.longitude = -0.1262362;
        mapRegion.span.latitudeDelta = 0.2;
        mapRegion.span.longitudeDelta = 0.2;
        mapView.setRegion(mapRegion, animated: true)
        
        // drop a pin on parliament square
        let parliamentLocation:CLLocationCoordinate2D = CLLocationCoordinate2DMake(51.5001524, -0.1262362)
        let parliamentAnnotation = PlacemarkClass(coordinate: parliamentLocation, title: "Parliament Square", subtitle: "Big Ben is here!")
        mapView.addAnnotation(parliamentAnnotation)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func mapView(mapView: MKMapView, viewForAnnotation annotation: MKAnnotation) -> MKAnnotationView?
    {
        let newAnnotation:MKPinAnnotationView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: "annotation1")
        
        newAnnotation.pinTintColor = UIColor.yellowColor()
        newAnnotation.animatesDrop = true
        newAnnotation.canShowCallout = true
        newAnnotation.setSelected(true, animated: true)
        
        return newAnnotation
    }
}

