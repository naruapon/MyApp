//
//  ViewController.swift
//  CollectionViewTest
//
//  Created by Abhishek Mishra on 12/05/2015.
//  Copyright (c) 2015 asm technology ltd. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {

    var statesOfMatter:Array<String> = ["Solid", "Liquid", "Gas"]
    
    var solids:Array<String> = ["Li", "Al", "Si"]
    
    var liquids:Array<String> = ["Hg"]
    
    var gasses:Array<String> = ["N", "O", "F"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        if section == 0
        {
            return solids.count
        }
        else if section == 1
        {
            return liquids.count
        }
        else if section == 2
        {
            return gasses.count
        }
        
        return 0
    }
    

    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell
    {
        let section =  indexPath.section
        var row = indexPath.row
        
        let cell: ElementCollectionViewCell = collectionView.dequeueReusableCellWithReuseIdentifier("ElementCellIdentifier", forIndexPath:indexPath) as! ElementCollectionViewCell
        
        if section == 0
        {
            let elementName:String = solids[indexPath.row]
            cell.imageView.image = UIImage(named: elementName)
        }
        else if section == 1
        {
            let elementName:String = liquids[indexPath.row]
            cell.imageView.image = UIImage(named: elementName)
        }
        else if section == 2
        {
            let elementName:String = gasses[indexPath.row]
            cell.imageView.image = UIImage(named: elementName)
        }
        
        return cell
    }
    
    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int
    {
        return statesOfMatter.count;
    }

}

