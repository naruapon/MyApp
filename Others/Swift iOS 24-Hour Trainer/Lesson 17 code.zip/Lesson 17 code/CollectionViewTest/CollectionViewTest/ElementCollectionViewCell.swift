//
//  ElementCollectionViewCell.swift
//  CollectionViewTest
//
//  Created by Abhishek Mishra on 13/05/2015.
//  Copyright (c) 2015 asm technology ltd. All rights reserved.
//

import UIKit

class ElementCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
}
