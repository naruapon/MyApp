//
//  SimpleButtonUITests.swift
//  SimpleButtonUITests
//
//  Created by Abhishek Mishra on 26/08/2015.
//  Copyright © 2015 asm technology ltd. All rights reserved.
//

import XCTest

class SimpleButtonUITests: XCTestCase {
        
    override func setUp() {
        super.setUp()
        
        // Put setup code here. This method is called before the invocation of each test method in the class.
        
        // In UI tests it is usually best to stop immediately when a failure occurs.
        continueAfterFailure = false
        // UI tests must launch the application that they test. Doing this in setup will make sure it happens for each test method.
        XCUIApplication().launch()
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testWhenButtonTapped_AlertAppears () {
        XCUIApplication().buttons["alertLauncherButton"].tap()
        let alert = XCUIApplication().alerts.element
        XCTAssertNotNil(alert.exists)

    }
    
    func testWhenButtonTapped_AlertAppearsWithCorrectTitle () {
        XCUIApplication().buttons["alertLauncherButton"].tap()
        let alert = XCUIApplication().alerts.element
        let alertTile:String = alert.label
        XCTAssertEqual(alertTile, "What is your name?")
        
    }

    
    func testWhenAlertDismissed_LabelUpdatesCorrectly () {
        XCUIApplication().buttons["alertLauncherButton"].tap()
        let alert = XCUIApplication().alerts.element
        
        alert.textFields.elementBoundByIndex(0).typeText("Alex")
        alert.buttons.elementBoundByIndex(0).tap()
        
        let label = XCUIApplication().staticTexts["Hello Alex"]
        let predicate = NSPredicate(format: "exists == 1", argumentArray: nil)
        self.expectationForPredicate(predicate, evaluatedWithObject: label, handler: nil)
        
        self.waitForExpectationsWithTimeout(5, handler: nil)        
    }

}
