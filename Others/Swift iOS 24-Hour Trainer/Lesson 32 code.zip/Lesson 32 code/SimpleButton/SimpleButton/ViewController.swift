//
//  ViewController.swift
//  SimpleButton
//
//  Created by Abhishek Mishra on 26/08/2015.
//  Copyright © 2015 asm technology ltd. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var greetingLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        greetingLabel.text = ""
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func onButtonTapped(sender: AnyObject) {
    
        var inputTextField: UITextField?
        
        let alert = UIAlertController(title: "What is your name?", message: nil, preferredStyle: UIAlertControllerStyle.Alert)
        
        let alertAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default, handler: { action -> Void in
            guard let textField = inputTextField else {
                return
            }
            
            self.greetingLabel.text = "Hello \(textField.text!)"
  
        })
        
        alert.addAction(alertAction)
        
        alert.addTextFieldWithConfigurationHandler { (textField) -> Void in
            inputTextField = textField;
            inputTextField!.text = ""
        }
        
        self.presentViewController(alert, animated: true, completion: nil)
        
    }

}

