//
//  ViewController.swift
//  PropertyListTest
//
//  Created by Abhishek Mishra on 11/06/2015.
//  Copyright © 2015 asm technology ltd. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var arrayOfContacts:NSArray? = nil
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        // load contacts.plist into arrayOfContacts
        let documentsDirectory:String = NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomainMask.UserDomainMask, true)[0] as String
        
        let plistPath = documentsDirectory + "/contacts.plist"
        
        arrayOfContacts = NSArray(contentsOfFile: plistPath)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCellWithIdentifier("prototypeCell1", forIndexPath: indexPath) as UITableViewCell
        
        let contactName:String = arrayOfContacts!.objectAtIndex(indexPath.row) as! String
        cell.textLabel?.text = contactName
        return cell
    }

    func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 1;
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arrayOfContacts!.count
    }


}


