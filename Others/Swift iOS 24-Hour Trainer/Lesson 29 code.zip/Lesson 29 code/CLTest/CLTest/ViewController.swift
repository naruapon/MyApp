//
//  ViewController.swift
//  CLTest
//
//  Created by Abhishek Mishra on 23/06/2015.
//  Copyright © 2015 asm technology ltd. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate {

    @IBOutlet weak var latitudeValue: UILabel!
    @IBOutlet weak var longitudeValue: UILabel!
    @IBOutlet weak var distanceValue: UILabel!
    @IBOutlet weak var toggleButton: UIButton!
    
    var locationManager:CLLocationManager? = nil
    var lastLocation:CLLocation? = nil
    var isReceivingLocationUpdates:Bool = false
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        locationManager = CLLocationManager()
        locationManager!.delegate = self
        locationManager!.desiredAccuracy = kCLLocationAccuracyBestForNavigation
        
        lastLocation = CLLocation(latitude: 51.5001524, longitude: -0.1262362)
        
        toggleButton.titleLabel!.text = "Start location updates"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func locationManager(manager: CLLocationManager, didChangeAuthorizationStatus status: CLAuthorizationStatus)
    {
        var shouldAllow = false
        
        switch status {
            case CLAuthorizationStatus.AuthorizedWhenInUse:
                shouldAllow = true
            case CLAuthorizationStatus.AuthorizedAlways:
                shouldAllow = true
            default:
                shouldAllow = false
        }
        
        if shouldAllow == true {
            isReceivingLocationUpdates = true
            toggleButton.titleLabel!.text = "Stop location updates"
            manager.startUpdatingLocation()
        }
    }
    

    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        let locationArray = locations as NSArray
        for newLocation in locationArray
        {
            // lat/lon values should only be considered if
            // horizontalAccuracy is not negative.
            if newLocation.horizontalAccuracy >= 0
            {
                let currentLatitude:CLLocationDegrees = newLocation.coordinate.latitude;
                let currentLongitude:CLLocationDegrees = newLocation.coordinate.longitude;
                let distanceTravelled = newLocation.distanceFromLocation(lastLocation!)
                
                latitudeValue.text = "\(currentLatitude)"
                longitudeValue.text = "\(currentLongitude)"
                distanceValue.text = "\(distanceTravelled)"
                
                lastLocation = newLocation as? CLLocation
            }
        }

    }
    
    
    @IBAction func onButtonPressed(sender: AnyObject) {
        
        if isReceivingLocationUpdates == false
        {
            if CLLocationManager.authorizationStatus() != CLAuthorizationStatus.AuthorizedWhenInUse
            {
                locationManager!.requestWhenInUseAuthorization()
            }
            else
            {
                isReceivingLocationUpdates = true
                toggleButton.titleLabel!.text = "Stop location updates"
                
                locationManager!.startUpdatingLocation()
            }
        }
        else
        {
            isReceivingLocationUpdates = false
            
            toggleButton.titleLabel!.text = "Start location updates"
            
            locationManager!.stopUpdatingLocation()
        }
        
    }

}

