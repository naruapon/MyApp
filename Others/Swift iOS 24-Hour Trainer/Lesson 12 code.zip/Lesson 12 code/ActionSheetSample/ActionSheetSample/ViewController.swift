//
//  ViewController.swift
//  ActionSheetSample
//
//  Created by Abhishek Mishra on 25/09/2015.
//  Copyright © 2015 asm technology ltd. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func onPresentActionSheet(sender: AnyObject) {
        
        let alert = UIAlertController(title: "Change background color",
                                     message: "Select a color",
                                    preferredStyle: UIAlertControllerStyle.ActionSheet)
        
        alert.addAction(UIAlertAction(title: "Red",
                                      style: UIAlertActionStyle.Default,
                                      handler: { (action: UIAlertAction) -> Void in
            self.view.backgroundColor = UIColor.redColor()
        }))
        
        alert.addAction(UIAlertAction(title: "Green",
            style: UIAlertActionStyle.Default,
            handler: { (action: UIAlertAction) -> Void in
                self.view.backgroundColor = UIColor.greenColor()
        }))
        
        alert.addAction(UIAlertAction(title: "Blue",
            style: UIAlertActionStyle.Default,
            handler: { (action: UIAlertAction) -> Void in
                self.view.backgroundColor = UIColor.blueColor()
        }))
        
        alert.addAction(UIAlertAction(title: "Yellow",
            style: UIAlertActionStyle.Default,
            handler: { (action: UIAlertAction) -> Void in
                self.view.backgroundColor = UIColor.yellowColor()
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel",
            style: UIAlertActionStyle.Cancel,
            handler:nil))

        
        self.presentViewController(alert, animated: true, completion: nil)
    }

}

