//
//  FruitClass.swift
//  FruitList
//
//  Created by Abhishek Mishra on 19/09/2015.
//  Copyright © 2015 asm technology ltd. All rights reserved.
//

import UIKit
import Foundation

class FruitClass: NSObject {
    
    var fruitName:String!
    var fruitImage:String!
    var fruitFamily:String!
    var fruitGenus:String!
    
    init (fruitName:String, fruitImage:String, fruitFamily:String, fruitGenus:String) {
        self.fruitName = fruitName;
        self.fruitImage = fruitImage;
        self.fruitFamily = fruitFamily;
        self.fruitGenus = fruitGenus;
    }
}
