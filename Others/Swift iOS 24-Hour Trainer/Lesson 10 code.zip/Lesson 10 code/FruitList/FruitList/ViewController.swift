//
//  ViewController.swift
//  FruitList
//
//  Created by Abhishek Mishra on 19/09/2015.
//  Copyright © 2015 asm technology ltd. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var arrayOfFruits:[FruitClass] = [FruitClass]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let apple:FruitClass = FruitClass(fruitName: "Apple",
                                          fruitImage: "apple",
                                          fruitFamily: "Rosacae",
                                          fruitGenus: "Malus")
        
        let banana:FruitClass = FruitClass(fruitName: "Banana",
                                           fruitImage: "banana",
                                           fruitFamily: "Musacae",
                                           fruitGenus: "Musa")
        
        let orange:FruitClass = FruitClass(fruitName: "Orange",
                                           fruitImage: "orange",
                                           fruitFamily: "Rutacae",
                                           fruitGenus: "Citrus")
        
        self.arrayOfFruits.append(apple);
        self.arrayOfFruits.append(banana);
        self.arrayOfFruits.append(orange);
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if (segue.identifier == "appleSegue") {
            var objectData:FruitClass = self.arrayOfFruits[0]
            let destination = segue.destinationViewController
                as! FruitDetailViewController
            destination.dataObject = objectData;
        }
            
        else if (segue.identifier == "bananaSegue") {
            var objectData:FruitClass = self.arrayOfFruits[1]
            let destination = segue.destinationViewController
                as! FruitDetailViewController
            destination.dataObject = objectData;
        }
            
        else if (segue.identifier == "orangeSegue") {
            var objectData:FruitClass = self.arrayOfFruits[2]
            let destination = segue.destinationViewController
                as! FruitDetailViewController
            destination.dataObject = objectData;
        }
    }

}

