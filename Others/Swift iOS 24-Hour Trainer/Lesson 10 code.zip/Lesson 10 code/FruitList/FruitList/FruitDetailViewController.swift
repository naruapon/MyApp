//
//  FruitDetailViewController.swift
//  FruitList
//
//  Created by Abhishek Mishra on 19/09/2015.
//  Copyright © 2015 asm technology ltd. All rights reserved.
//

import UIKit

class FruitDetailViewController: UIViewController {

    var dataObject:FruitClass?
    
    @IBOutlet weak var fruitImage: UIImageView!
    
    @IBOutlet weak var fruitNameLabel: UILabel!
    @IBOutlet weak var fruitFamilyLabel: UILabel!
    @IBOutlet weak var fruitGenusLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        guard let dataObject = dataObject else {
            return
        }
        
        fruitImage.image = UIImage(named: dataObject.fruitImage)
        fruitNameLabel.text = "Name: \(dataObject.fruitName)"
        fruitFamilyLabel.text = "Family: \(dataObject.fruitFamily)"
        fruitGenusLabel.text = "Genus: \(dataObject.fruitGenus)"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func onBack(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
