//
//  ArithmeticCalculator.swift
//  SwiftCalculator
//
//  Created by Abhishek Mishra on 17/08/2015.
//  Copyright © 2015 Abhishek Mishra. All rights reserved.
//

import Foundation

enum ArithmeticCalculatorExeceptions : ErrorType {
    case DivideByZeroException
}

class ArithmeticCalculator: NSObject {
    
    func addNumbers(firstNumber number1:Double, secondNumber number2:Double) -> Double{
        return number1 + number2
    }
    
    func subtractNumbers(firstNumber number1:Double, secondNumber number2:Double) -> Double{
        return number1 - number2
    }
    
    func divideNumbers(numerator number1:Double, denominator number2:Double) -> Double? {
        
        if number2 == 0 {
            return nil
        }
        
        return number1 / number2
    }
    
    func multiplyNumbers(firstNumber number1:Double, secondNumber number2:Double) -> Double{
        return number1 * number2
    }
}
