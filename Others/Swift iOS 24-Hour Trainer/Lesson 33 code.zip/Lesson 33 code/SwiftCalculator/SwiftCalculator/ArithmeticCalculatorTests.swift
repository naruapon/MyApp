//
//  ArithmeticCalculatorTests.swift
//  SwiftCalculator
//
//  Created by Abhishek Mishra on 17/08/2015.
//  Copyright © 2015 Abhishek Mishra. All rights reserved.
//

import XCTest

class ArithmeticCalculatorTests: XCTestCase {
    
    override func setUp() {
        super.setUp()

    }
    
    override func tearDown() {

        super.tearDown()
    }
    
    func testInitializerDoesNotReturnNilInstance() {
        XCTAssertNotNil(ArithmeticCalculator())
    }
    
    func testAddNumbers_PositiveN1_PositiveN2_ReturnsValidResult() {
        let calculator:ArithmeticCalculator = ArithmeticCalculator()
        let n1:Double = 10
        let n2:Double = 20
        let result:Double = calculator.addNumbers(firstNumber: n1, secondNumber: n2)
        XCTAssertEqual(result, n1 + n2)
    }
    
    func testAddNumbers_PositiveN1_ZeroN2_ReturnsNumber1() {
        let calculator:ArithmeticCalculator = ArithmeticCalculator()
        let n1:Double = 10
        let n2:Double = 0
        let result:Double = calculator.addNumbers(firstNumber: n1, secondNumber: n2)
        XCTAssertEqual(result, n1)
    }
    
    func testSubtractNumbers_PositiveN1_SmallerPositiveN2_ReturnsValidResult() {
        let calculator:ArithmeticCalculator = ArithmeticCalculator()
        let n1:Double = 20
        let n2:Double = 10
        let result:Double = calculator.subtractNumbers(firstNumber: n1, secondNumber: n2)
        XCTAssertEqual(result, n1 - n2)
    }
    
    func testMultiplyNumbers_PositiveN1_PositiveN2_ReturnsValidResult() {
        let calculator:ArithmeticCalculator = ArithmeticCalculator()
        let n1:Double = 20
        let n2:Double = 10
        let result:Double = calculator.multiplyNumbers(firstNumber: n1, secondNumber: n2)
        XCTAssertEqual(result, n1 * n2)
    }
    
    func testMultiplyNumbers_NegativeeN1_NegativeN2_ReturnsValidPositiveResult() {
        let calculator:ArithmeticCalculator = ArithmeticCalculator()
        let n1:Double = 20
        let n2:Double = 10
        let result:Double = calculator.multiplyNumbers(firstNumber: n1, secondNumber: n2)
        XCTAssert(result >= 0)
    }


    func testDivideNumbers_PositiveN1_PositiveN2_ReturnsValidResult() {
        let calculator:ArithmeticCalculator = ArithmeticCalculator()
        let n1:Double = 20
        let n2:Double = 10
        let result:Double? = calculator.divideNumbers(numerator: n1, denominator: n2)
        XCTAssertEqual(result!, n1 / n2)
    }
    
    func testDivideNumbers_NegativeN1_NegativeN2_ReturnsValidPositiveResult() {
        let calculator:ArithmeticCalculator = ArithmeticCalculator()
        let n1:Double = -20
        let n2:Double = -10
        let result:Double? = calculator.divideNumbers(numerator: n1, denominator: n2)
        XCTAssert(result! >= 0)
    }
    
    func testDivideNumbers_PositiveN1_ZeroN2_ReturnsNil() {
        let calculator:ArithmeticCalculator = ArithmeticCalculator()
        let n1:Double = 20
        let n2:Double = 0
        let result:Double? = calculator.divideNumbers(numerator: n1, denominator: n2)
        XCTAssertNil(result)
    }
}
