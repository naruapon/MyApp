//
//  ViewController.swift
//  SwiftCalculator
//
//  Created by Abhishek Mishra on 14/08/2015.
//  Copyright © 2015 Abhishek Mishra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var numberField1: UITextField!
    @IBOutlet weak var numberField2: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func onAdd(sender: AnyObject) {
        
        numberField1.resignFirstResponder()
        numberField2.resignFirstResponder()
        
        let number1:String? = numberField1.text
        let number2:String? = numberField2.text
    
        if let n1 = number1, n2 = number2 {
            
            if n1.isEmpty || n2.isEmpty {
                return
            }
            
            let firstNumber:Double? = NSNumberFormatter().numberFromString(n1)?.doubleValue
            let secondNumber:Double? = NSNumberFormatter().numberFromString(n2)?.doubleValue
            
            if let fN = firstNumber, sN = secondNumber {
                
                let calculator:ArithmeticCalculator = ArithmeticCalculator()
                let result:Double = calculator.addNumbers(firstNumber: fN, secondNumber: sN)
                
                let alert = UIAlertController(title: "",
                            message: "\(fN) + \(sN) = \(result)",
                            preferredStyle: UIAlertControllerStyle.Alert)
            
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default, handler: nil))
                
                self.presentViewController(alert, animated: true, completion: nil)
            }
        }
    }
    
    @IBAction func onSubtract(sender: AnyObject) {
        
        numberField1.resignFirstResponder()
        numberField2.resignFirstResponder()
        
        let number1:String? = numberField1.text
        let number2:String? = numberField2.text
        
        if let n1 = number1, n2 = number2 {
            
            if n1.isEmpty || n2.isEmpty {
                return
            }
            
            let firstNumber:Double? = NSNumberFormatter().numberFromString(n1)?.doubleValue
            let secondNumber:Double? = NSNumberFormatter().numberFromString(n2)?.doubleValue
            
            if let fN = firstNumber, sN = secondNumber {
                
                let calculator:ArithmeticCalculator = ArithmeticCalculator()
                let result:Double = calculator.subtractNumbers(firstNumber: fN, secondNumber: sN)
                
                let alert = UIAlertController(title: "",
                    message: "\(fN) - \(sN) = \(result)",
                    preferredStyle: UIAlertControllerStyle.Alert)
                
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default, handler: nil))
                
                self.presentViewController(alert, animated: true, completion: nil)
            }
        }
        
    }
    
    @IBAction func onMultiply(sender: AnyObject) {
        
        numberField1.resignFirstResponder()
        numberField2.resignFirstResponder()
        
        let number1:String? = numberField1.text
        let number2:String? = numberField2.text
        
        if let n1 = number1, n2 = number2 {
            
            if n1.isEmpty || n2.isEmpty {
                return
            }
            
            let firstNumber:Double? = NSNumberFormatter().numberFromString(n1)?.doubleValue
            let secondNumber:Double? = NSNumberFormatter().numberFromString(n2)?.doubleValue
            
            if let fN = firstNumber, sN = secondNumber {
                
                let calculator:ArithmeticCalculator = ArithmeticCalculator()
                let result:Double = calculator.multiplyNumbers(firstNumber: fN, secondNumber: sN)
                
                let alert = UIAlertController(title: "",
                    message: "\(fN) * \(sN) = \(result)",
                    preferredStyle: UIAlertControllerStyle.Alert)
                
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default, handler: nil))
                
                self.presentViewController(alert, animated: true, completion: nil)
            }
        }
        
    }
    
    @IBAction func onDivide(sender: AnyObject) {
     
        numberField1.resignFirstResponder()
        numberField2.resignFirstResponder()
        
        let number1:String? = numberField1.text
        let number2:String? = numberField2.text
        
        if let n1 = number1, n2 = number2 {
            
            if n1.isEmpty || n2.isEmpty {
                return
            }
            
            let firstNumber:Double? = NSNumberFormatter().numberFromString(n1)?.doubleValue
            let secondNumber:Double? = NSNumberFormatter().numberFromString(n2)?.doubleValue
            
            if let fN = firstNumber, sN = secondNumber {
                
                let calculator:ArithmeticCalculator = ArithmeticCalculator()
                let result:Double! = calculator.divideNumbers(numerator: fN, denominator: sN)
                
                if result == nil {
                    
                    let alert = UIAlertController(title: "Error",
                        message: "Division by Zero",
                        preferredStyle: UIAlertControllerStyle.Alert)
                    
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default, handler: nil))
                    
                    self.presentViewController(alert, animated: true, completion: nil)
                }
                else
                {
                    let alert = UIAlertController(title: "",
                        message: "\(fN) / \(sN) = \(result!)",
                        preferredStyle: UIAlertControllerStyle.Alert)
                    
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default, handler: nil))
                    
                    self.presentViewController(alert, animated: true, completion: nil)
                }
            }
        }
    }
    
}

