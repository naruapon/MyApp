//
//  ViewController.swift
//  SettingsTest
//
//  Created by Abhishek Mishra on 15/06/2015.
//  Copyright © 2015 asm technology ltd. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var ageLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let userDefaults = NSUserDefaults()
        let registrationDictionary:[String: String] = ["user_name":"Paul Woods", "user_age":"28"]
        
        userDefaults.registerDefaults(registrationDictionary)
        userDefaults.synchronize()
        
        nameLabel.text = userDefaults.valueForKey("user_name") as? String
        ageLabel.text = userDefaults.valueForKey("user_age") as? String
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

