//
//  ViewController.swift
//  GestureTest
//
//  Created by Abhishek Mishra on 14/06/2015.
//  Copyright © 2015 asm technology ltd. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var gestureType: UILabel!
    
    @IBAction func onTapGestureDetected(sender: AnyObject) {
        gestureType.text = "Tap gesture detected"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}

